print('Sabor Express\n')

print('1. Cadastrar restaurante')
print('2. Listar restaurante')
print('3. Ativar restaurante')
print('4. Sair \n')

opcao_escolhida = int(input('escolha uma opção:'))
print(f'voce escolheu a opção {opcao_escolhida}')

def finalizar_app()